# db.py — SLASH Surveillance Database
# Laptop deployment: cloud-first with local fallback
# ──────────────────────────────────────────────────
# Behavior:
#   • Internet available  → writes directly to MongoDB Atlas (cloud)
#   • Internet lost       → writes to local MongoDB (localhost:27017)
#   • Internet restored   → syncs all offline records to Atlas, switches back
#
# Requirements:
#   pip install pymongo python-dotenv
#
# .env file (create in same folder):
#   ATLAS_URI=mongodb+srv://username:password@cluster.mongodb.net/
#   CAMERA_ID=laptop_dev
#   LOCATION=Lab

import os
import uuid
import socket
import threading
import time
from datetime import datetime, timezone

from pymongo import MongoClient, errors
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

LOCAL_URI        = "mongodb://localhost:27017/"
ATLAS_URI        = os.getenv("ATLAS_URI", "")
DB_NAME          = "slash_surveillance"
CAMERA_ID        = os.getenv("CAMERA_ID", "laptop_dev")
LOCATION         = os.getenv("LOCATION", "Lab")
MONITOR_INTERVAL = 15    # seconds between internet checks
ATLAS_TIMEOUT_MS = 4000  # ms before Atlas connection attempt times out


# ─────────────────────────────────────────────
# INTERNET CHECK
# ─────────────────────────────────────────────

def has_internet() -> bool:
    """Check internet by trying multiple hosts — more reliable on restricted networks."""
    hosts = [
        ("8.8.8.8",        53),
        ("1.1.1.1",        53),
        ("208.67.222.222", 53),
        ("www.google.com", 80),
    ]
    for host, port in hosts:
        try:
            socket.setdefaulttimeout(3)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((host, port))
            s.close()
            return True
        except Exception:
            continue
    return False


# ─────────────────────────────────────────────
# DATABASE CLASS
# ─────────────────────────────────────────────

class SurveillanceDB:
    """
    Cloud-first MongoDB handler with automatic local fallback.

    Usage:
        db = SurveillanceDB()
        db.start_session()
        db.log_violation(
            type="smoking",
            confidence="HIGH",
            offender_key="smoke_(350, 200)",
            frame_no=142,
            bounding_box=[120, 80, 300, 420],
            image_path="alerts/smoking_HIGH_350-200_20250115.jpg"
        )
        db.end_session()
    """

    def __init__(self):
        # Always connect to local MongoDB — this is the fallback
        try:
            self._local_client = MongoClient(LOCAL_URI, serverSelectionTimeoutMS=3000)
            self._local_client.admin.command("ping")
            self.local = self._local_client[DB_NAME]
            print("[DB] Local MongoDB connected (localhost:27017)")
        except Exception as e:
            print(f"[DB] WARNING: Local MongoDB not available: {e}")
            print("[DB] Start MongoDB with: mongod --dbpath /data/db")
            self.local = None

        # Atlas (cloud) — attempt connection
        self.atlas      = None
        self.online     = False
        self.session_id = None

        self._connect_atlas()

        # Background thread monitors internet and handles sync
        monitor = threading.Thread(target=self._monitor_loop, daemon=True)
        monitor.start()

    # ── Connection ────────────────────────────────────────────

    def _connect_atlas(self):
        """Try to connect to Atlas. On success, sync any pending local records."""
        if not ATLAS_URI:
            print("[DB] No ATLAS_URI in .env — running local only")
            return

        internet = has_internet()
        print(f"[DB] Internet check: {'OK' if internet else 'FAILED'}")
        if not internet:
            print("[DB] No internet — using local MongoDB")
            return

        try:
            client = MongoClient(
                ATLAS_URI,
                serverSelectionTimeoutMS=ATLAS_TIMEOUT_MS,
                tls=True,
                tlsAllowInvalidCertificates=True  # bypass SSL inspection by network/firewall
            )
            client.admin.command("ping")
            self.atlas  = client[DB_NAME]
            self.online = True
            print("[DB] Connected to MongoDB Atlas (cloud)")
            self._sync_pending()
        except Exception as e:
            print(f"[DB] Atlas unavailable ({e}) — using local MongoDB")
            self.online = False
            self.atlas  = None

    def _monitor_loop(self):
        """
        Runs in background. Switches between cloud/local as internet changes.
        Uses exponential back-off when Atlas keeps failing to avoid log spam.
        """
        backoff = MONITOR_INTERVAL
        while True:
            time.sleep(backoff)
            internet_now = has_internet()

            if internet_now and not self.online:
                print("[DB] Internet restored — reconnecting to Atlas...")
                self._connect_atlas()
                if self.online:
                    backoff = MONITOR_INTERVAL      # reset on success
                else:
                    backoff = min(backoff * 2, 120) # slow down if Atlas still failing

            elif not internet_now and self.online:
                print("[DB] Internet lost — switching to local MongoDB")
                self.online = False
                self.atlas  = None
                backoff     = MONITOR_INTERVAL

    # ── Active DB ─────────────────────────────────────────────

    @property
    def active(self):
        """Returns Atlas if online, local MongoDB if offline."""
        if self.online and self.atlas is not None:
            return self.atlas
        return self.local

    # ── Session Management ────────────────────────────────────

    def start_session(self, camera_id: str = None, location: str = None):
        """Call once at the start of each surveillance run."""
        camera_id = camera_id or CAMERA_ID
        location  = location  or LOCATION

        session = {
            "session_id":       str(uuid.uuid4()),
            "start_time":       datetime.now(timezone.utc),
            "end_time":         None,
            "camera_id":        camera_id,
            "location":         location,
            "device":           "laptop",
            "total_violations": 0,
            "status":           "active",
            "synced":           self.online,
        }

        if self.active is None:
            print("[DB] WARNING: No database available. Session not saved.")
            return

        result = self.active.sessions.insert_one(session)
        self.session_id = result.inserted_id
        mode = "cloud" if self.online else "local"
        print(f"[DB] Session started ({mode}): {session['session_id'][:8]}...")

    def end_session(self):
        """Call once when surveillance run ends."""
        if self.active is None or self.session_id is None:
            return

        self.active.sessions.update_one(
            {"_id": self.session_id},
            {"$set": {
                "end_time": datetime.now(timezone.utc),
                "status":   "ended"
            }}
        )
        print("[DB] Session ended.")

    # ── Log Violation ─────────────────────────────────────────

    def log_violation(
        self,
        type:         str,
        confidence:   str,
        offender_key: str,
        frame_no:     int,
        bounding_box: list,
        image_path    = None,
        camera_id:    str = None,
        extra:        dict = None,
    ):
        """Save a violation event to the active database."""
        if self.active is None:
            print("[DB] WARNING: No database — violation not logged.")
            return

        camera_id = camera_id or CAMERA_ID

        doc = {
            "type":          type,
            "confidence":    confidence,
            "offender_key":  str(offender_key),
            "timestamp":     datetime.now(timezone.utc),
            "frame_no":      int(frame_no),
            "bounding_box":  [int(v) for v in (bounding_box or [])],
            "image_path":    str(image_path) if image_path else None,
            "camera_id":     camera_id,
            "session_id":    str(self.session_id) if self.session_id else None,
            "device":        "laptop",
            "synced":        self.online,
            "was_offline":   not self.online,
        }

        # Merge extra metadata, sanitising numpy types
        if extra:
            for k, v in extra.items():
                if v is None:
                    continue
                try:
                    import numpy as np
                    if isinstance(v, np.integer):
                        v = int(v)
                    elif isinstance(v, np.floating):
                        v = float(v)
                except ImportError:
                    pass
                doc[k] = v

        if self.online:
            try:
                self.atlas.violations.insert_one(doc)
                if self.session_id:
                    self.atlas.sessions.update_one(
                        {"_id": self.session_id},
                        {"$inc": {"total_violations": 1}}
                    )
                return  # success

            except errors.PyMongoError as e:
                print(f"[DB] Atlas write failed ({e}) — saving locally")
                self.online = False
                self.atlas  = None

        # Offline path
        doc["synced"]      = False
        doc["was_offline"] = True

        if self.local is None:
            print("[DB] CRITICAL: Both Atlas and local MongoDB unavailable!")
            return

        self.local.violations.insert_one(doc)

        if self.session_id:
            self.local.sessions.update_one(
                {"_id": self.session_id},
                {"$inc": {"total_violations": 1}}
            )

    # ── Sync Local → Atlas ────────────────────────────────────

    def _sync_pending(self):
        """Push all unsynced local records to Atlas. Called when internet restores."""
        if not self.online or self.atlas is None or self.local is None:
            return

        unsynced = list(self.local.violations.find({"synced": False}))
        if not unsynced:
            print("[DB] No pending records to sync.")
            return

        print(f"[DB] Syncing {len(unsynced)} offline violation(s) to Atlas...")
        success = 0

        for doc in unsynced:
            local_id = doc.pop("_id")
            doc["synced"]    = True
            doc["synced_at"] = datetime.now(timezone.utc)

            try:
                self.atlas.violations.insert_one(doc)
                self.local.violations.update_one(
                    {"_id": local_id},
                    {"$set": {"synced": True, "synced_at": datetime.now(timezone.utc)}}
                )
                success += 1
            except Exception as e:
                print(f"[DB] Sync failed for record {local_id}: {e}")
                doc["_id"] = local_id
                break

        print(f"[DB] Sync complete: {success}/{len(unsynced)} records pushed to Atlas")

        # Sync sessions too
        for session in list(self.local.sessions.find({"synced": False})):
            sid = session.pop("_id")
            session["synced"] = True
            try:
                self.atlas.sessions.insert_one(session)
                self.local.sessions.update_one(
                    {"_id": sid}, {"$set": {"synced": True}}
                )
            except Exception:
                pass

    def force_sync(self):
        """Manually trigger a sync."""
        if not has_internet():
            print("[DB] No internet — cannot sync now.")
            return
        if not self.online:
            self._connect_atlas()
        self._sync_pending()

    # ── Status ────────────────────────────────────────────────

    def status(self) -> dict:
        """Returns current DB status for the HUD indicator."""
        unsynced = 0
        if self.local is not None:
            try:
                unsynced = self.local.violations.count_documents({"synced": False})
            except Exception:
                pass

        if self.online:
            mode = "cloud"
        elif self.local is not None:
            mode = "local"
        else:
            mode = "unavailable"

        return {
            "mode":      mode,
            "unsynced":  unsynced,
            "online":    self.online,
            "atlas_uri": bool(ATLAS_URI),
        }

    # ── Query Helpers ─────────────────────────────────────────

    def get_recent_violations(self, limit: int = 20) -> list:
        """Returns the most recent violations from the active database."""
        if self.active is None:
            return []
        return list(
            self.active.violations
            .find({}, {"_id": 0})
            .sort("timestamp", -1)
            .limit(limit)
        )

    def get_violation_counts(self) -> dict:
        """Returns total counts by violation type."""
        if self.active is None:
            return {}
        pipeline = [{"$group": {"_id": "$type", "count": {"$sum": 1}}}]
        return {i["_id"]: i["count"] for i in self.active.violations.aggregate(pipeline)}

    def get_today_count(self) -> int:
        """Returns number of violations recorded today."""
        if self.active is None:
            return 0
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        return self.active.violations.count_documents({"timestamp": {"$gte": today}})


# ─────────────────────────────────────────────
# QUICK TEST  (run: python db.py)
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("\n── SLASH DB Test ──")
    db = SurveillanceDB()
    time.sleep(1)

    db.start_session(camera_id="laptop_dev", location="Lab")

    db.log_violation(
        type         = "smoking",
        confidence   = "HIGH",
        offender_key = "smoke_(350, 200)",
        frame_no     = 142,
        bounding_box = [120, 80, 300, 420],
        image_path   = "alerts/test_alert.jpg",
    )

    db.log_violation(
        type         = "litter_throw",
        confidence   = "MEDIUM",
        offender_key = "litter_3",
        frame_no     = 210,
        bounding_box = [200, 150, 280, 230],
    )

    status = db.status()
    print(f"\n── Status ──")
    print(f"  Mode     : {status['mode']}")
    print(f"  Unsynced : {status['unsynced']}")
    print(f"  Online   : {status['online']}")

    db.end_session()
    print("\n── Test complete ──\n")